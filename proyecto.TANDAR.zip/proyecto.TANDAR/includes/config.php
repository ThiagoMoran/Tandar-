<?php
// ============================================================
// includes/config.php  —  EDITAR antes de subir
// ============================================================
 
// --- Base de datos (AlwaysData) ---
define('DB_NAME', 'lautaro_sistema');
define('DB_USER', 'lautaro');
define('DB_PASS', 'sistema.2026');
define('DB_HOST', 'mysql-lautaro.alwaysdata.net');
 
// --- Aplicación ---
define('APP_NAME',  'Mi Sistema');
define('APP_URL',   'https://lautaro.alwaysdata.net'); // URL pública
 
// --- Google OAuth ---
define('GOOGLE_CLIENT_ID',     '974689501257-74ckjja4i55o3b5tirtd5qnckaibc2fs.apps.googleusercontent.com');
define('GOOGLE_CLIENT_SECRET', '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');
define('GOOGLE_REDIRECT_URI',  APP_URL . '/auth/google_callback.php');
 
// --- Email (para PHPMailer) ---
define('MAIL_HOST',     'smtp.gmail.com');
define('MAIL_PORT',     587);
define('MAIL_USER',     'lautarofernandez6907@gmail.com');
define('MAIL_PASS',     'tttp gzgi juoh ddxc');   // App Password, no la contraseña real
define('MAIL_FROM',     'lautarofernandez6907@gmail.com');
define('MAIL_FROM_NAME', APP_NAME);
 
// --- Sesión ---
define('SESSION_NAME', 'SISPHP_SESS');
define('SESSION_LIFETIME', 3600); // 1 hora
 
// --- Seguridad ---
define('HASH_COST', 12);   // costo bcrypt
 