<?php
// includes/propuestas.php
// Centraliza todas las transiciones de estado de propuestas_modificacion.
// Siempre actualiza en par: solicitudes.estado_id + propuestas_modificacion.estado_id
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/notificaciones.php';

// ------------------------------------------------------------
// ADMIN: crear una nueva propuesta de modificación
// ------------------------------------------------------------
function crear_propuesta(
    int $solicitud_id,
    int $admin_id,
    string $fecha_desde,
    string $fecha_hasta,
    string $motivo
): int {
    // solicitud → modificacion_propuesta (7)
    db()->prepare("UPDATE solicitudes SET estado_id = 7 WHERE id = ?")
        ->execute([$solicitud_id]);

    // propuesta → pendiente_acuerdo_responsable_linea (1)
    db()->prepare("
        INSERT INTO propuestas_modificacion
            (solicitud_id, administrador_id, fecha_desde, fecha_hasta, motivo, estado_id)
        VALUES (?, ?, ?, ?, ?, 1)
    ")->execute([$solicitud_id, $admin_id, $fecha_desde, $fecha_hasta, $motivo]);

    return (int)db()->lastInsertId();
}

// ------------------------------------------------------------
// RESPONSABLE: acuerda la propuesta → pasa a esperar confirmación del usuario
// ------------------------------------------------------------
function responsable_acuerda_propuesta(int $propuesta_id, int $responsable_id): void {
    $pm = _get_propuesta($propuesta_id);

    // propuesta → pendiente_confirmacion_usuario (2)
    db()->prepare("
        UPDATE propuestas_modificacion
        SET estado_id = 2,
            responsable_id = ?,
            fecha_respuesta_responsable = NOW()
        WHERE id = ?
    ")->execute([$responsable_id, $propuesta_id]);

    // solicitud se mantiene en 7 (modificacion_propuesta), notificamos al usuario
    crear_notificacion($pm['usuario_solicitante'], 5, $pm['solicitud_id']);
}

// ------------------------------------------------------------
// RESPONSABLE: rechaza la propuesta → solicitud vuelve a aprobada
// ------------------------------------------------------------
function responsable_rechaza_propuesta(int $propuesta_id, int $responsable_id): void {
    $pm = _get_propuesta($propuesta_id);

    // propuesta → rechazada_por_responsable_linea (4)
    db()->prepare("
        UPDATE propuestas_modificacion
        SET estado_id = 4,
            responsable_id = ?,
            fecha_respuesta_responsable = NOW()
        WHERE id = ?
    ")->execute([$responsable_id, $propuesta_id]);

    // solicitud vuelve a aprobada (5)
    db()->prepare("UPDATE solicitudes SET estado_id = 5 WHERE id = ?")
        ->execute([$pm['solicitud_id']]);

    // notificamos al admin
    crear_notificacion($pm['administrador_id'], 7, $pm['solicitud_id']);
}

// ------------------------------------------------------------
// USUARIO: confirma la propuesta
// ------------------------------------------------------------
function usuario_confirma_propuesta(int $propuesta_id, int $usuario_id): void {
    $pm = _get_propuesta($propuesta_id);

    // Registrar respuesta del usuario
    db()->prepare("
        INSERT INTO respuestas_usuario (solicitud_id, usuario_id, accion)
        VALUES (?, ?, 'confirmada')
    ")->execute([$pm['solicitud_id'], $usuario_id]);

    db()->prepare("
        UPDATE propuestas_modificacion SET fecha_respuesta_usuario = NOW() WHERE id = ?
    ")->execute([$propuesta_id]);

    // Verificar si el horario sigue libre
    $chk = db()->prepare("
        SELECT id FROM calendario
        WHERE linea_experimental_id = ? AND estado = 'reservado'
        AND fecha BETWEEN ? AND ?
    ");
    $chk->execute([$pm['linea_id'], $pm['fecha_desde'], $pm['fecha_hasta']]);

    if ($chk->fetch()) {
        // Horario tomado → invalidar
        db()->prepare("UPDATE propuestas_modificacion SET estado_id = 6 WHERE id = ?")
            ->execute([$propuesta_id]);

        db()->prepare("UPDATE solicitudes SET estado_id = 8 WHERE id = ?")
            ->execute([$pm['solicitud_id']]);

        crear_notificacion($usuario_id, 8, $pm['solicitud_id']);
    } else {
        // Horario libre → aprobar con fechas acordadas
        db()->prepare("
            UPDATE propuestas_modificacion SET estado_id = 3 WHERE id = ?
        ")->execute([$propuesta_id]);

        db()->prepare("
            UPDATE solicitudes
            SET estado_id = 5,
                fecha_acordada_desde = ?,
                fecha_acordada_hasta = ?
            WHERE id = ?
        ")->execute([$pm['fecha_desde'], $pm['fecha_hasta'], $pm['solicitud_id']]);

        // Bloquear en calendario
        db()->prepare("
            INSERT INTO calendario
                (solicitud_id, linea_experimental_id, fecha, hora_inicio, hora_fin, estado)
            VALUES (?, ?, ?, '08:00:00', '18:00:00', 'reservado')
            ON DUPLICATE KEY UPDATE estado = 'reservado'
        ")->execute([
            $pm['solicitud_id'],
            $pm['linea_id'],
            $pm['fecha_desde'],
        ]);

        crear_notificacion($pm['administrador_id'], 6, $pm['solicitud_id']);
    }
}

// ------------------------------------------------------------
// USUARIO: rechaza la propuesta → solicitud vuelve a aprobada
// ------------------------------------------------------------
function usuario_rechaza_propuesta(int $propuesta_id, int $usuario_id): void {
    $pm = _get_propuesta($propuesta_id);

    // Registrar respuesta del usuario
    db()->prepare("
        INSERT INTO respuestas_usuario (solicitud_id, usuario_id, accion)
        VALUES (?, ?, 'rechazada')
    ")->execute([$pm['solicitud_id'], $usuario_id]);

    db()->prepare("
        UPDATE propuestas_modificacion
        SET estado_id = 5, fecha_respuesta_usuario = NOW()
        WHERE id = ?
    ")->execute([$propuesta_id]);

    // solicitud vuelve a aprobada (5)
    db()->prepare("UPDATE solicitudes SET estado_id = 5 WHERE id = ?")
        ->execute([$pm['solicitud_id']]);

    crear_notificacion($pm['administrador_id'], 7, $pm['solicitud_id']);
}

// ------------------------------------------------------------
// Helper interno: trae datos de la propuesta + solicitud en una sola query
// ------------------------------------------------------------
function _get_propuesta(int $propuesta_id): array {
    $stmt = db()->prepare("
        SELECT pm.*,
               s.linea_id,
               s.usuario_id AS usuario_solicitante
        FROM propuestas_modificacion pm
        JOIN solicitudes s ON s.id = pm.solicitud_id
        WHERE pm.id = ?
    ");
    $stmt->execute([$propuesta_id]);
    $row = $stmt->fetch();
    if (!$row) throw new RuntimeException("Propuesta #$propuesta_id no encontrada.");
    return $row;
}