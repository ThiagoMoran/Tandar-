<?php
// includes/mailer.php
// Requiere: composer require phpmailer/phpmailer
// En AlwaysData instalar via SSH: composer require phpmailer/phpmailer

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/../vendor/autoload.php';

function send_reset_email(string $destinatario, string $nombre, string $token): bool {
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = MAIL_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = MAIL_USER;
        $mail->Password   = MAIL_PASS;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = MAIL_PORT;
        $mail->CharSet    = 'UTF-8';

        $mail->setFrom(MAIL_FROM, MAIL_FROM_NAME);
        $mail->addAddress($destinatario, $nombre);

        $link = APP_URL . '/auth/reset_password.php?token=' . urlencode($token);

        $mail->isHTML(true);
        $mail->Subject = 'Recupero de contraseña — ' . APP_NAME;
        $mail->Body    = "
            <h2>Recupero de contraseña</h2>
            <p>Hola <strong>{$nombre}</strong>,</p>
            <p>Hacé clic en el siguiente botón para restablecer tu contraseña. El enlace expira en <strong>30 minutos</strong>.</p>
            <p style='margin:24px 0'>
              <a href='{$link}' style='background:#4f46e5;color:#fff;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:bold'>
                Restablecer contraseña
              </a>
            </p>
            <p style='color:#888;font-size:13px'>Si no solicitaste este correo, ignoralo.</p>
        ";
        $mail->AltBody = "Copiá este enlace en tu navegador: {$link}";

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log('Mailer Error: ' . $mail->ErrorInfo);
        return false;
    }
}