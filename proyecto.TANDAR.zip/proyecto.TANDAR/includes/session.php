<?php
// includes/session.php
require_once __DIR__ . '/config.php';

function session_init(): void {
    if (session_status() === PHP_SESSION_NONE) {
        session_name(SESSION_NAME);
        session_set_cookie_params([
            'lifetime' => SESSION_LIFETIME,
            'path'     => '/',
            'secure'   => true,
            'httponly' => true,
            'samesite' => 'None',
        ]);
        session_start();
    }
}

function login_user(array $usuario): void {
    session_regenerate_id(true);          // previene session fixation
    $_SESSION['user_id']   = $usuario['id'];
    $_SESSION['user_nombre'] = $usuario['nombre'];
    $_SESSION['user_email'] = $usuario['email'];
    $_SESSION['user_rol']  = $usuario['rol_nombre'];
    $_SESSION['_csrf']     = bin2hex(random_bytes(32));
}

function logout_user(): void {
    session_unset();
    session_destroy();
}

function is_logged_in(): bool {
    return !empty($_SESSION['user_id']);
}

function require_login(): void {
    if (!is_logged_in()) {
        header('Location: /auth/login.php');
        exit;
    }
}

function require_role(string ...$roles): void {
    require_login();
    if (!in_array($_SESSION['user_rol'], $roles, true)) {
        http_response_code(403);
        die('403 — No tenés permiso para acceder a esta página.');
    }
}

function current_user_rol(): string {
    return $_SESSION['user_rol'] ?? '';
}

// Validación CSRF
function csrf_token(): string {
    return $_SESSION['_csrf'] ?? '';
}

function csrf_verify(string $token): bool {
    return hash_equals($_SESSION['_csrf'] ?? '', $token);
}