<?php
// includes/db.php
require_once __DIR__ . '/config.php';
 
function db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            // Nunca exponer detalles de BD en producción
            error_log('DB Error: ' . $e->getMessage());
            die('Error de conexión. Contacte al administrador.');
        }
    }
    return $pdo;
}
 