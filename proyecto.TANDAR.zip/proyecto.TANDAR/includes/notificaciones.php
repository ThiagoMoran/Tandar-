<?php
// includes/notificaciones.php
require_once __DIR__ . '/db.php';

// Devuelve el texto genérico según el tipo de notificación
function texto_notificacion(int $tipo_id): string {
    $textos = [
        1 => 'Nueva solicitud de turno pendiente de evaluación.',
        2 => 'Tu solicitud de turno fue aprobada.',
        3 => 'Tu solicitud fue rechazada. Revisá el motivo en "Mis turnos".',
        4 => 'Tu solicitud fue modificada por el responsable de línea. Revisá los detalles en "Mis turnos".',
        5 => 'Hay una nueva propuesta de modificación para tu turno. Revisala en "Mis turnos".',
        6 => 'El usuario confirmó la propuesta de modificación.',
        7 => 'El usuario rechazó la propuesta de modificación.',
        8 => 'La propuesta fue invalidada: el horario fue tomado por otro usuario.',
    ];
    return $textos[$tipo_id] ?? 'Tenés una nueva notificación sobre un turno.';
}

// Inserta una notificación de forma centralizada
function crear_notificacion(int $usuario_id, int $tipo_id, ?int $solicitud_id = null): void {
    db()->prepare("
        INSERT INTO notificaciones (usuario_id, tipo_id, solicitud_id, enviado)
        VALUES (?, ?, ?, 0)
    ")->execute([$usuario_id, $tipo_id, $solicitud_id]);
}