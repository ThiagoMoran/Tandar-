<?php
require_once '../includes/config.php';
require_once '../includes/session.php';
require_once '../includes/db.php';
require_once '../includes/notificaciones.php';
require_once '../includes/propuestas.php';

session_init();
require_role('administrador');

$uid     = $_SESSION['user_id'];
$mensaje = $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['_csrf'] ?? '')) {
        $error = 'Token inválido.';
    } else {
        $accion       = $_POST['accion'] ?? '';
        $solicitud_id = (int)($_POST['solicitud_id'] ?? 0);
        $motivo       = trim($_POST['motivo'] ?? '');

        if (!$solicitud_id) {
            $error = 'Solicitud inválida.';
        } elseif (in_array($accion, ['rechazar', 'modificar']) && !$motivo) {
            $error = 'El motivo es obligatorio.';
        } else {
            $sol = db()->prepare("SELECT * FROM solicitudes WHERE id = ?");
            $sol->execute([$solicitud_id]);
            $solicitud = $sol->fetch();

            if (!$solicitud) {
                $error = 'Solicitud no encontrada.';
            } else {
                if ($accion === 'aprobar') {
                    db()->prepare("
                        UPDATE solicitudes
                        SET estado_id = 5,
                            fecha_acordada_desde = fecha_solicitada_desde,
                            fecha_acordada_hasta = fecha_solicitada_hasta
                        WHERE id = ?
                    ")->execute([$solicitud_id]);

                    db()->prepare("
                        INSERT INTO evaluaciones_administrador (solicitud_id, usuario_id, decision, motivo)
                        VALUES (?, ?, 'aprobar', NULL)
                    ")->execute([$solicitud_id, $uid]);

                    db()->prepare("
                        INSERT INTO calendario
                            (solicitud_id, linea_experimental_id, fecha, hora_inicio, hora_fin, estado)
                        VALUES (?, ?, ?, '08:00:00', '18:00:00', 'reservado')
                        ON DUPLICATE KEY UPDATE estado = 'reservado'
                    ")->execute([
                        $solicitud_id,
                        $solicitud['linea_id'],
                        $solicitud['fecha_solicitada_desde'],
                    ]);

                    crear_notificacion($solicitud['usuario_id'], 2, $solicitud_id);

                    $mensaje = "Solicitud #$solicitud_id aprobada y registrada en el calendario.";

                } elseif ($accion === 'rechazar') {
                    db()->prepare("UPDATE solicitudes SET estado_id = 6 WHERE id = ?")
                        ->execute([$solicitud_id]);

                    db()->prepare("
                        INSERT INTO evaluaciones_administrador (solicitud_id, usuario_id, decision, motivo)
                        VALUES (?, ?, 'rechazar', ?)
                    ")->execute([$solicitud_id, $uid, $motivo]);

                    crear_notificacion($solicitud['usuario_id'], 3, $solicitud_id);

                    $mensaje = "Solicitud #$solicitud_id rechazada.";

                } elseif ($accion === 'modificar') {
                    $fp_ini = $_POST['fecha_propuesta_desde'] ?? '';
                    $fp_fin = $_POST['fecha_propuesta_hasta'] ?? '';

                    if (!$fp_ini || !$fp_fin) {
                        $error = 'Completá las fechas propuestas.';
                    } elseif ($fp_fin < $fp_ini) {
                        $error = 'La fecha hasta debe ser igual o posterior a desde.';
                    } else {
                        crear_propuesta($solicitud_id, $uid, $fp_ini, $fp_fin, $motivo);
                        $mensaje = "Propuesta de modificación enviada para la solicitud #$solicitud_id.";
                    }
                }
            }
        }
    }
}

// Solicitudes pendientes de acción (estado 4 = pendiente_administrador, 7 = modificacion_propuesta)
$pendientes = db()->query("
    SELECT s.id, s.fecha_solicitada_desde, s.fecha_solicitada_hasta,
           s.titulo_experimento, s.observaciones, s.estado_id, s.creado_en,
           l.nombre AS linea,
           u.nombre AS usr_nombre, u.apellido AS usr_apellido, u.email AS usr_email,
           er.decision AS decision_resp, er.motivo AS motivo_resp
    FROM solicitudes s
    JOIN lineas_experimentales l ON s.linea_id = l.id
    JOIN usuarios u ON s.usuario_id = u.id
    LEFT JOIN evaluaciones_responsable er ON er.solicitud_id = s.id
    WHERE s.estado_id IN (4, 7)
    ORDER BY s.fecha_solicitada_desde ASC
")->fetchAll();

$historial = db()->query("
    SELECT s.id, s.fecha_solicitada_desde, s.fecha_solicitada_hasta, s.estado_id,
           es.nombre AS estado_nombre,
           l.nombre AS linea,
           u.nombre AS usr_nombre, u.apellido AS usr_apellido,
           ea.motivo AS motivo_admin, ea.creado_en AS fecha_accion
    FROM solicitudes s
    JOIN lineas_experimentales l ON s.linea_id = l.id
    JOIN usuarios u ON s.usuario_id = u.id
    JOIN estados_solicitud es ON s.estado_id = es.id
    LEFT JOIN evaluaciones_administrador ea ON ea.solicitud_id = s.id
    WHERE s.estado_id IN (5, 6, 8)
    ORDER BY ea.creado_en DESC LIMIT 20
")->fetchAll();

$stats = db()->query("
    SELECT
        SUM(estado_id = 4)       AS pendientes,
        SUM(estado_id = 5)       AS aprobadas,
        SUM(estado_id IN (3, 6)) AS rechazadas,
        SUM(estado_id = 7)       AS en_modif
    FROM solicitudes
")->fetch();
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Panel Administrador — TANDAR</title>
<link rel="stylesheet" href="/public/css/tandar.css">
</head>
<body>

<div class="tn-topbar">
    <span>TANDAR Intranet — CNEA · Centro Atómico Constituyentes</span>
    <div>
        <span>👤 <?= htmlspecialchars($_SESSION['user_nombre']) ?></span>
        <a href="/auth/logout.php">Cerrar sesión</a>
    </div>
</div>

<nav class="tn-navbar">
    <a href="/turnos/panel_admin.php" class="tn-brand">
        <div class="tn-logo"><span>TAN</span><small>DAR</small></div>
        <div class="tn-brand-text">
            <strong>TANDAR Intranet</strong>
            <em>Panel de administrador</em>
        </div>
    </a>
    <div class="tn-nav-links">
        <a href="/turnos/panel_admin.php" class="active">Solicitudes</a>
        <a href="/admin/users.php">Usuarios</a>
        <a href="/auth/logout.php" class="tn-btn-logout">Salir</a>
    </div>
</nav>

<div class="tn-page-header">
    <h1>Panel de Administrador</h1>
    <p>Gestión de solicitudes de turno — TANDAR</p>
</div>

<div class="tn-container">

    <?php if ($mensaje): ?>
        <div class="tn-page-alert success">✔ <?= htmlspecialchars($mensaje) ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="tn-page-alert error">⚠ <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="tn-stats">
        <div class="tn-stat pend">
            <div class="tn-stat-num"><?= $stats['pendientes'] ?? 0 ?></div>
            <div class="tn-stat-label">Pendientes</div>
        </div>
        <div class="tn-stat aprov">
            <div class="tn-stat-num"><?= $stats['aprobadas'] ?? 0 ?></div>
            <div class="tn-stat-label">Aprobadas</div>
        </div>
        <div class="tn-stat rech">
            <div class="tn-stat-num"><?= $stats['rechazadas'] ?? 0 ?></div>
            <div class="tn-stat-label">Rechazadas</div>
        </div>
        <div class="tn-stat modif">
            <div class="tn-stat-num"><?= $stats['en_modif'] ?? 0 ?></div>
            <div class="tn-stat-label">En modificación</div>
        </div>
    </div>

    <div class="tn-section-title">Solicitudes pendientes de acción <span class="tn-dot"></span></div>

    <?php if (empty($pendientes)): ?>
        <div class="tn-empty" style="margin-bottom:28px;">
            <div class="tn-empty-icon">✅</div>
            <h3>Sin solicitudes pendientes</h3>
            <p>No hay solicitudes que requieran tu acción.</p>
        </div>
    <?php endif; ?>

    <?php foreach ($pendientes as $s):
        $cls = $s['estado_id'] === 7 ? 'modif' : 'pend';
    ?>
    <div class="tn-card <?= $cls ?>">
        <div class="tn-card-header">
            <span class="tn-card-id">#<?= $s['id'] ?> — <?= htmlspecialchars($s['linea']) ?></span>
            <span class="tn-badge <?= $cls ?>">
                <?= $s['estado_id'] === 7 ? 'Modificación propuesta' : 'Pendiente admin' ?>
            </span>
        </div>
        <div class="tn-meta">
            <span>
                <span class="tn-avatar">
                    <?= strtoupper(substr($s['usr_nombre'], 0, 1) . substr($s['usr_apellido'], 0, 1)) ?>
                </span>
                <?= htmlspecialchars($s['usr_nombre'] . ' ' . $s['usr_apellido']) ?>
                — <?= htmlspecialchars($s['usr_email']) ?>
            </span>
        </div>
        <div class="tn-meta">
            <span>📅 <?= date('d/m/Y', strtotime($s['fecha_solicitada_desde'])) ?></span>
            <span>→ <?= date('d/m/Y', strtotime($s['fecha_solicitada_hasta'])) ?></span>
            <span>🗓 <?= date('d/m/Y H:i', strtotime($s['creado_en'])) ?></span>
        </div>
        <div class="tn-motivo">
            <strong>Experimento:</strong> <?= htmlspecialchars($s['titulo_experimento']) ?>
            <?php if ($s['observaciones']): ?>
                <br><strong>Observaciones:</strong> <?= htmlspecialchars($s['observaciones']) ?>
            <?php endif; ?>
        </div>

        <?php if ($s['decision_resp']): ?>
            <div class="tn-nota-resp">
                ✅ Responsable de línea: <strong><?= ucfirst($s['decision_resp']) ?></strong>
                <?php if ($s['motivo_resp']): ?>
                    — <?= htmlspecialchars($s['motivo_resp']) ?>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <div class="tn-acciones">
            <div class="tn-tabs">
                <button class="tn-tab ap" onclick="toggle(<?= $s['id'] ?>, 'ap')">✔ Aprobar</button>
                <button class="tn-tab re" onclick="toggle(<?= $s['id'] ?>, 're')">✖ Rechazar</button>
                <button class="tn-tab mo" onclick="toggle(<?= $s['id'] ?>, 'mo')">✏ Proponer modificación</button>
            </div>

            <div id="p<?= $s['id'] ?>-ap" class="tn-action-panel">
                <form method="POST">
                    <input type="hidden" name="_csrf" value="<?= htmlspecialchars(csrf_token()) ?>">
                    <input type="hidden" name="solicitud_id" value="<?= $s['id'] ?>">
                    <input type="hidden" name="accion" value="aprobar">
                    <p style="font-size:13px;margin-bottom:10px;">El turno quedará registrado en el calendario.</p>
                    <button type="submit" class="tn-btn success">✔ Confirmar aprobación</button>
                </form>
            </div>

            <div id="p<?= $s['id'] ?>-re" class="tn-action-panel">
                <form method="POST">
                    <input type="hidden" name="_csrf" value="<?= htmlspecialchars(csrf_token()) ?>">
                    <input type="hidden" name="solicitud_id" value="<?= $s['id'] ?>">
                    <input type="hidden" name="accion" value="rechazar">
                    <label>Motivo de rechazo <span class="tn-req">*</span></label>
                    <textarea name="motivo" placeholder="Explicá el motivo del rechazo..." required></textarea>
                    <button type="submit" class="tn-btn danger" style="margin-top:10px;">✖ Confirmar rechazo</button>
                </form>
            </div>

            <div id="p<?= $s['id'] ?>-mo" class="tn-action-panel">
                <form method="POST">
                    <input type="hidden" name="_csrf" value="<?= htmlspecialchars(csrf_token()) ?>">
                    <input type="hidden" name="solicitud_id" value="<?= $s['id'] ?>">
                    <input type="hidden" name="accion" value="modificar">
                    <div class="tn-form-row">
                        <div>
                            <label>Fecha desde <span class="tn-req">*</span></label>
                            <input type="date" name="fecha_propuesta_desde" min="<?= date('Y-m-d') ?>" required>
                        </div>
                        <div>
                            <label>Fecha hasta <span class="tn-req">*</span></label>
                            <input type="date" name="fecha_propuesta_hasta" min="<?= date('Y-m-d') ?>" required>
                        </div>
                    </div>
                    <label style="margin-top:10px;">Motivo <span class="tn-req">*</span></label>
                    <textarea name="motivo" placeholder="Explicá por qué se propone este cambio..." required></textarea>
                    <button type="submit" class="tn-btn" style="background:var(--azul-med);color:#fff;margin-top:10px;">
                        ✏ Enviar propuesta
                    </button>
                </form>
            </div>
        </div>
    </div>
    <?php endforeach; ?>

    <div class="tn-section-title" style="margin-top:30px;">Historial reciente</div>

    <?php if (empty($historial)): ?>
        <div class="tn-empty">
            <div class="tn-empty-icon">📁</div>
            <h3>Sin historial todavía</h3>
        </div>
    <?php else: ?>
        <div class="tn-tabla-wrap">
            <table class="tn-tabla">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Usuario</th>
                        <th>Línea</th>
                        <th>Desde</th>
                        <th>Hasta</th>
                        <th>Estado</th>
                        <th>Fecha acción</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($historial as $h):
                    $bc = [5 => 'aprov', 6 => 'rech', 8 => 'inv'];
                    $c  = $bc[$h['estado_id']] ?? '';
                ?>
                    <tr>
                        <td>#<?= $h['id'] ?></td>
                        <td>
                            <span class="tn-avatar">
                                <?= strtoupper(substr($h['usr_nombre'], 0, 1) . substr($h['usr_apellido'], 0, 1)) ?>
                            </span>
                            <?= htmlspecialchars($h['usr_nombre'] . ' ' . $h['usr_apellido']) ?>
                        </td>
                        <td><?= htmlspecialchars($h['linea']) ?></td>
                        <td><?= date('d/m/Y', strtotime($h['fecha_solicitada_desde'])) ?></td>
                        <td><?= date('d/m/Y', strtotime($h['fecha_solicitada_hasta'])) ?></td>
                        <td><span class="tn-badge <?= $c ?>"><?= htmlspecialchars($h['estado_nombre']) ?></span></td>
                        <td style="color:var(--muted)">
                            <?= $h['fecha_accion'] ? date('d/m/Y H:i', strtotime($h['fecha_accion'])) : '—' ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>

    <div class="tn-footer">TANDAR — CNEA · Centro Atómico Constituyentes</div>
</div>

<script>
function toggle(id, tipo) {
    ['ap', 're', 'mo'].forEach(t => {
        document.getElementById('p' + id + '-' + t)?.classList.remove('visible');
    });
    document.getElementById('p' + id + '-' + tipo)?.classList.toggle('visible');
}
</script>
</body>
</html> 