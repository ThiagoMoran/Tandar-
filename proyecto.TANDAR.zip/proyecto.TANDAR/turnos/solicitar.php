<?php
require_once '../includes/config.php';
require_once '../includes/session.php';
require_once '../includes/db.php';

session_init();
require_role('usuario');

$uid     = $_SESSION['user_id'];
$mensaje = $error = '';

$lineas = db()->query("SELECT id, nombre FROM lineas_experimentales WHERE activa = 1 ORDER BY nombre")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['_csrf'] ?? '')) {
        $error = 'Token inválido. Recargá la página.';
    } else {
        $linea_id  = (int)($_POST['linea_id'] ?? 0);
        $fecha_ini = $_POST['fecha_desde'] ?? '';
        $fecha_fin = $_POST['fecha_hasta'] ?? '';
        $titulo    = trim($_POST['titulo_experimento'] ?? '');
        $obs       = trim($_POST['observaciones'] ?? '');
        $tipo_haz  = $_POST['tipo_haz'] ?? 'interno';

        if (!$linea_id || !$fecha_ini || !$fecha_fin || !$titulo) {
            $error = 'Los campos marcados con * son obligatorios.';
        } elseif ($fecha_fin < $fecha_ini) {
            $error = 'La fecha hasta debe ser igual o posterior a la fecha desde.';
        } elseif (strtotime($fecha_ini) < strtotime('today')) {
            $error = 'No se puede solicitar una fecha pasada.';
        } else {
            // Verificar disponibilidad en calendario
            $chk = db()->prepare("
                SELECT id FROM calendario
                WHERE linea_experimental_id = ? AND estado = 'reservado'
                AND fecha BETWEEN ? AND ?
            ");
            $chk->execute([$linea_id, $fecha_ini, $fecha_fin]);

            if ($chk->fetch()) {
                $error = 'Las fechas seleccionadas están ocupadas en esa línea experimental.';
            } else {
                // Calcular numero_correlativo dentro del año actual
                $anio_actual = (int)date('Y');

                $cor = db()->prepare("
                    SELECT COALESCE(MAX(numero_correlativo), 0) + 1
                    FROM solicitudes
                    WHERE anio = ?
                ");
                $cor->execute([$anio_actual]);
                $numero_correlativo = (int)$cor->fetchColumn();

                // nombre_expediente requerido por la tabla, lo generamos automático
                $nombre_expediente = sprintf('TANDAR-%d-%04d', $anio_actual, $numero_correlativo);

                $ins = db()->prepare("
                    INSERT INTO solicitudes
                        (numero_correlativo, anio, nombre_expediente,
                         usuario_id, linea_id, fecha_solicitada_desde, fecha_solicitada_hasta,
                         titulo_experimento, observaciones, tipo_haz, estado_id)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
                ");
                $ins->execute([
                    $numero_correlativo,
                    $anio_actual,
                    $nombre_expediente,
                    $uid,
                    $linea_id,
                    $fecha_ini,
                    $fecha_fin,
                    $titulo,
                    $obs,
                    $tipo_haz,
                ]);
                $solicitud_id = db()->lastInsertId();

                // Notificar al responsable de la línea
                $resp = db()->prepare("
                    SELECT u.id FROM responsables_linea rl
                    JOIN usuarios u ON rl.usuario_id = u.id
                    WHERE rl.linea_id = ? LIMIT 1
                ");
                $resp->execute([$linea_id]);
                $responsable_id = $resp->fetchColumn();

                require_once '../includes/notificaciones.php';
// ...
if ($responsable_id) {
    crear_notificacion($responsable_id, 1, $solicitud_id);
}

                $mensaje = "Solicitud enviada correctamente. Expediente: $nombre_expediente. Quedará pendiente de revisión por el responsable de línea.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Solicitar turno — TANDAR</title>
<link rel="stylesheet" href="/public/css/tandar.css">
</head>
<body>

<div class="tn-topbar">
    <span>TANDAR Intranet — CNEA · Centro Atómico Constituyentes</span>
    <div>
        <span>👤 <?= htmlspecialchars($_SESSION['user_nombre']) ?></span>
        <a href="/auth/logout.php">Cerrar sesión</a>
    </div>
</div>

<nav class="tn-navbar">
    <a href="/turnos/mis_turnos.php" class="tn-brand">
        <div class="tn-logo"><span>TAN</span><small>DAR</small></div>
        <div class="tn-brand-text">
            <strong>TANDAR Intranet</strong>
            <em>Panel de investigador</em>
        </div>
    </a>
    <div class="tn-nav-links">
        <a href="/turnos/mis_turnos.php">Mis turnos</a>
        <a href="/turnos/solicitar.php" class="active">Solicitar turno</a>
        <a href="/auth/logout.php" class="tn-btn-logout">Salir</a>
    </div>
</nav>

<div class="tn-page-header">
    <h1>Solicitar turno de irradiación</h1>
    <p>Completá el formulario para enviar tu solicitud</p>
</div>

<div class="tn-container" style="max-width:720px;">

    <?php if ($mensaje): ?>
        <div class="tn-page-alert success">✔ <?= htmlspecialchars($mensaje) ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="tn-page-alert error">⚠ <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="tn-form-card">
        <div class="tn-info-box">
            ⚠ La solicitud será evaluada primero por el responsable de línea y luego por el administrador. No podrá modificarse una vez enviada.
        </div>

        <form method="POST">
            <input type="hidden" name="_csrf" value="<?= htmlspecialchars(csrf_token()) ?>">

            <div class="tn-form-group">
                <label>Línea experimental <span class="tn-req">*</span></label>
                <select name="linea_id" required>
                    <option value="">— Seleccioná una línea —</option>
                    <?php foreach ($lineas as $l): ?>
                        <option value="<?= $l['id'] ?>"
                            <?= (($_POST['linea_id'] ?? '') == $l['id']) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($l['nombre']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="tn-form-group">
                <label>Título del experimento <span class="tn-req">*</span></label>
                <input type="text" name="titulo_experimento"
                       value="<?= htmlspecialchars($_POST['titulo_experimento'] ?? '') ?>"
                       placeholder="Ej: Dispersión elástica de O-16 sobre Pb-208"
                       required>
            </div>

            <div class="tn-form-group">
                <div class="tn-form-2col">
                    <div>
                        <label>Fecha desde <span class="tn-req">*</span></label>
                        <input type="date" name="fecha_desde"
                               min="<?= date('Y-m-d') ?>"
                               value="<?= htmlspecialchars($_POST['fecha_desde'] ?? '') ?>"
                               required>
                    </div>
                    <div>
                        <label>Fecha hasta <span class="tn-req">*</span></label>
                        <input type="date" name="fecha_hasta"
                               min="<?= date('Y-m-d') ?>"
                               value="<?= htmlspecialchars($_POST['fecha_hasta'] ?? '') ?>"
                               required>
                    </div>
                </div>
            </div>

            <div class="tn-form-group">
                <label>Tipo de haz</label>
                <select name="tipo_haz">
                    <option value="interno" <?= (($_POST['tipo_haz'] ?? '') === 'interno') ? 'selected' : '' ?>>Interno</option>
                    <option value="externo" <?= (($_POST['tipo_haz'] ?? '') === 'externo') ? 'selected' : '' ?>>Externo</option>
                </select>
            </div>

            <div class="tn-form-group">
                <label>Observaciones / Parámetros de haz</label>
                <textarea name="observaciones"
                          placeholder="Energía, intensidad, tipo de ión, blancos, detectores requeridos..."><?= htmlspecialchars($_POST['observaciones'] ?? '') ?></textarea>
            </div>

            <div style="display:flex; gap:12px; justify-content:flex-end; margin-top:8px;">
                <a href="/turnos/mis_turnos.php" class="tn-btn secondary">Cancelar</a>
                <button type="submit" class="tn-btn primary">Enviar solicitud</button>
            </div>
        </form>
    </div>

    <div class="tn-footer">TANDAR — CNEA · Centro Atómico Constituyentes</div>
</div>
</body>
</html>