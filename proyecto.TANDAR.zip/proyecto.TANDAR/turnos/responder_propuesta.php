<?php
require_once '../includes/config.php';
require_once '../includes/session.php';
require_once '../includes/db.php';
require_once '../includes/propuestas.php';

session_init();
require_role('usuario');

$uid          = $_SESSION['user_id'];
$solicitud_id = (int)($_GET['id'] ?? 0);
$accion       = $_GET['accion'] ?? '';

if (!in_array($accion, ['confirmar', 'rechazar']) || !$solicitud_id) {
    header('Location: /turnos/mis_turnos.php');
    exit;
}

// Verificar que la solicitud pertenece al usuario y tiene propuesta pendiente (estado 7)
$stmt = db()->prepare("
    SELECT pm.id AS propuesta_id
    FROM solicitudes s
    JOIN propuestas_modificacion pm ON pm.solicitud_id = s.id
    WHERE s.id = ? AND s.usuario_id = ? AND s.estado_id = 7
      AND pm.estado_id = 2
    ORDER BY pm.id DESC
    LIMIT 1
");
$stmt->execute([$solicitud_id, $uid]);
$row = $stmt->fetch();

if (!$row) {
    header('Location: /turnos/mis_turnos.php');
    exit;
}

$propuesta_id = $row['propuesta_id'];

if ($accion === 'confirmar') {
    usuario_confirma_propuesta($propuesta_id, $uid);
} else {
    usuario_rechaza_propuesta($propuesta_id, $uid);
}

header('Location: /turnos/mis_turnos.php');
exit;