<?php
require_once '../includes/config.php';
require_once '../includes/session.php';
require_once '../includes/db.php';

session_init();
require_role('usuario');

$uid = $_SESSION['user_id'];

$stmt = db()->prepare("
    SELECT s.id, s.fecha_solicitada_desde, s.fecha_solicitada_hasta,
           s.titulo_experimento, s.observaciones, s.creado_en,
           s.estado_id, es.nombre AS estado_nombre,
           l.nombre AS linea,
           ea.motivo AS motivo_admin,
           pm.fecha_desde, pm.fecha_hasta
    FROM solicitudes s
    JOIN estados_solicitud es ON s.estado_id = es.id
    JOIN lineas_experimentales l ON s.linea_id = l.id
    LEFT JOIN evaluaciones_administrador ea ON ea.solicitud_id = s.id
    LEFT JOIN propuestas_modificacion pm ON pm.solicitud_id = s.id
    WHERE s.usuario_id = ?
    ORDER BY s.creado_en DESC
");
$stmt->execute([$uid]);
$turnos = $stmt->fetchAll();

$card_class = [
    1 => 'pend',
    2 => 'modif',
    3 => 'rech',
    4 => 'pend',
    5 => 'aprov',
    6 => 'rech',
    7 => 'modif',
    8 => 'inv',
];
$etiquetas = [
    1 => 'Pendiente — Responsable',
    2 => 'Modificada por responsable',
    3 => 'Rechazada por responsable',
    4 => 'Pendiente — Administrador',
    5 => 'Aprobada',
    6 => 'Rechazada',
    7 => 'Modificación propuesta',
    8 => 'Propuesta invalidada',
];
?>

?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Mis turnos — TANDAR</title>
<link rel="stylesheet" href="/public/css/tandar.css">
</head>
<body>

<div class="tn-topbar">
    <span>TANDAR Intranet — CNEA · Centro Atómico Constituyentes</span>
    <div>
        <span>👤 <?= htmlspecialchars($_SESSION['user_nombre']) ?></span>
        <a href="/auth/logout.php">Cerrar sesión</a>
    </div>
</div>

<nav class="tn-navbar">
    <a href="/turnos/mis_turnos.php" class="tn-brand">
        <div class="tn-logo"><span>TAN</span><small>DAR</small></div>
        <div class="tn-brand-text">
            <strong>TANDAR Intranet</strong>
            <em>Panel de investigador</em>
        </div>
    </a>
    <div class="tn-nav-links">
        <a href="/turnos/mis_turnos.php" class="active">Mis turnos</a>
        <a href="/turnos/solicitar.php">Solicitar turno</a>
        <a href="/auth/logout.php" class="tn-btn-logout">Salir</a>
    </div>
</nav>

<div class="tn-page-header">
    <h1>Mis turnos de irradiación</h1>
    <p>Historial y estado de todas tus solicitudes</p>
</div>

<div class="tn-container">

    <div style="display:flex; justify-content:flex-end; margin-bottom:20px;">
        <a href="/turnos/solicitar.php" class="tn-btn primary">+ Nueva solicitud</a>
    </div>

    <?php if (empty($turnos)): ?>
        <div class="tn-empty">
            <div class="tn-empty-icon">📋</div>
            <h3>No tenés solicitudes todavía</h3>
            <p>Hacé clic en "Nueva solicitud" para reservar tu primer turno de irradiación.</p>
        </div>
    <?php endif; ?>

    <?php foreach ($turnos as $t):
        $cls = $card_class[$t['estado_id']] ?? 'pend';
        $etq = $etiquetas[$t['estado_id']] ?? $t['estado_nombre'];
    ?>
    <div class="tn-card <?= $cls ?>">
        <div class="tn-card-header">
            <span class="tn-card-id">#<?= $t['id'] ?> — <?= htmlspecialchars($t['linea']) ?></span>
            <span class="tn-badge <?= $cls ?>"><?= $etq ?></span>
        </div>

        <div class="tn-meta">
            <span>📅 Desde: <?= date('d/m/Y', strtotime($t['fecha_solicitada_desde'])) ?></span>
            <span>📅 Hasta: <?= date('d/m/Y', strtotime($t['fecha_solicitada_hasta'])) ?></span>
            <span>🗓 Solicitado el <?= date('d/m/Y H:i', strtotime($t['creado_en'])) ?></span>
        </div>

        <div class="tn-motivo">
            <strong>Experimento:</strong> <?= htmlspecialchars($t['titulo_experimento']) ?>
            <?php if ($t['observaciones']): ?>
                <br><strong>Observaciones:</strong> <?= htmlspecialchars($t['observaciones']) ?>
            <?php endif; ?>
        </div>

        <?php if (in_array($t['estado_id'], [3, 6]) && $t['motivo_admin']): ?>
            <div class="tn-alert error">
                <strong>Motivo de rechazo:</strong> <?= htmlspecialchars($t['motivo_admin']) ?>
            </div>
        <?php endif; ?>

        <?php if ($t['estado_id'] === 7 && $t['fecha_desde']): ?>
            <div class="tn-alert info">
                <strong>El administrador propone modificar tu turno:</strong><br>
                📅 Desde: <?= date('d/m/Y', strtotime($t['fecha_desde'])) ?>
                📅 Hasta: <?= date('d/m/Y', strtotime($t['fecha_hasta'])) ?>
                <?php if ($t['motivo_admin']): ?>
                    <br><em>Motivo: <?= htmlspecialchars($t['motivo_admin']) ?></em>
                <?php endif; ?>
                <div style="margin-top:12px; display:flex; gap:8px;">
                    <a href="/turnos/responder_propuesta.php?id=<?= $t['id'] ?>&accion=confirmar"
                       class="tn-btn success sm">✔ Confirmar</a>
                    <a href="/turnos/responder_propuesta.php?id=<?= $t['id'] ?>&accion=rechazar"
                       class="tn-btn danger sm">✖ Rechazar</a>
                </div>
            </div>
        <?php endif; ?>

        <?php if ($t['estado_id'] === 8): ?>
            <div class="tn-alert warn">
                ⚠ La propuesta fue invalidada porque ese horario fue tomado por otro usuario. Solicitá una nueva fecha disponible.
            </div>
        <?php endif; ?>
    </div>
    <?php endforeach; ?>

    <div class="tn-footer">TANDAR — CNEA · Centro Atómico Constituyentes</div>
</div>
</body>
</html>