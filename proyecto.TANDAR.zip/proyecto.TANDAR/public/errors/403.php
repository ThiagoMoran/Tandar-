<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/session.php';
session_init();
$logueado = isset($_SESSION['user_id']);
$nombre   = $_SESSION['user_nombre'] ?? '';
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Acceso denegado — TANDAR</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
:root {
    --azul: #1a3a52;
    --naranja: #e8632a;
    --gris-bg: #f6f7f9;
    --gris-bd: #e8eaed;
    --muted: #8893a1;
    --rojo: #d64545;
    --rojo-lt: #fdeeee;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
body {
    font-family: 'Inter', sans-serif;
    background: linear-gradient(135deg, #14304a 0%, var(--azul) 60%, #1f4a6b 100%);
    min-height: 100vh;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    position: relative;
    overflow: hidden;
}
.bg-dots {
    position: absolute; inset: 0;
    background-image: radial-gradient(circle, rgba(232,99,42,0.15) 1px, transparent 1px);
    background-size: 30px 30px;
    pointer-events: none;
}
.card {
    position: relative; z-index: 2;
    background: white;
    border-radius: 20px;
    padding: 48px 44px;
    width: 420px;
    box-shadow: 0 25px 70px rgba(0,0,0,0.35);
    border-top: 4px solid var(--rojo);
    text-align: center;
}
.logo-box {
    width: 56px; height: 56px;
    background: linear-gradient(135deg, var(--azul), #0d2235);
    border-radius: 14px;
    display: inline-flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    margin-bottom: 20px;
    gap: 1px;
    box-shadow: 0 4px 14px rgba(26,58,82,0.35);
}
.logo-box span  { color: var(--naranja); font-size: 14px; font-weight: 800; letter-spacing: 1px; }
.logo-box small { color: #9bb8d0; font-size: 7px; letter-spacing: 0.6px; }

.error-code {
    font-size: 72px;
    font-weight: 800;
    color: var(--rojo);
    line-height: 1;
    letter-spacing: -0.03em;
    margin-bottom: 8px;
    opacity: 0.15;
    position: absolute;
    top: 20px; right: 28px;
}
h2 {
    font-size: 20px;
    font-weight: 800;
    color: var(--azul);
    letter-spacing: -0.02em;
    margin-bottom: 10px;
}
.desc {
    font-size: 13.5px;
    color: var(--muted);
    line-height: 1.6;
    margin-bottom: 28px;
}
.usuario-info {
    background: var(--gris-bg);
    border: 1px solid var(--gris-bd);
    border-radius: 10px;
    padding: 12px 16px;
    font-size: 13px;
    color: var(--azul);
    margin-bottom: 24px;
    font-weight: 500;
    display: flex;
    align-items: center;
    gap: 10px;
}
.avatar {
    width: 32px; height: 32px;
    border-radius: 9px;
    background: #d6e8f9;
    color: var(--azul);
    font-size: 12px; font-weight: 700;
    display: flex; align-items: center; justify-content: center;
    flex-shrink: 0;
}
.usuario-info .info-text { text-align: left; line-height: 1.3; }
.usuario-info .info-text span { display: block; font-size: 11px; color: var(--muted); font-weight: 400; }

.btn {
    display: block;
    width: 100%;
    padding: 12px;
    border-radius: 10px;
    font-size: 14px;
    font-weight: 700;
    border: none;
    cursor: pointer;
    text-decoration: none;
    text-align: center;
    transition: all 0.15s;
    margin-bottom: 10px;
    font-family: inherit;
}
.btn-logout {
    background: var(--rojo);
    color: #fff;
    box-shadow: 0 3px 10px rgba(214,69,69,0.3);
}
.btn-logout:hover { background: #c13838; transform: translateY(-1px); }
.btn-back {
    background: var(--gris-bg);
    color: var(--azul);
    border: 1.5px solid var(--gris-bd);
}
.btn-back:hover { background: var(--gris-bd); }
.btn-login {
    background: var(--naranja);
    color: #fff;
    box-shadow: 0 3px 10px rgba(232,99,42,0.3);
}
.btn-login:hover { background: #d4571f; transform: translateY(-1px); }

.footer {
    position: relative; z-index: 2;
    margin-top: 20px;
    font-size: 11px;
    color: rgba(255,255,255,0.4);
    font-weight: 500;
}
</style>
</head>
<body>
<div class="bg-dots"></div>

<div class="card">
    <div class="error-code">403</div>

    <div class="logo-box">
        <span>TAN</span>
        <small>DAR</small>
    </div>

    <h2>Acceso denegado</h2>
    <p class="desc">
        No tenés permisos para acceder a esta página.<br>
        <?php if ($logueado): ?>
            Si creés que es un error, contactá al administrador.
        <?php else: ?>
            Iniciá sesión para continuar.
        <?php endif; ?>
    </p>

    <?php if ($logueado): ?>
        <div class="usuario-info">
            <div class="avatar"><?= strtoupper(substr($nombre, 0, 2)) ?></div>
            <div class="info-text">
                <?= htmlspecialchars($nombre) ?>
                <span>Sesión activa</span>
            </div>
        </div>
        <a href="javascript:history.back()" class="btn btn-back">← Volver atrás</a>
        <a href="/auth/logout.php" class="btn btn-logout">Cerrar sesión</a>
    <?php else: ?>
        <a href="/auth/login.php" class="btn btn-login">Iniciar sesión</a>
    <?php endif; ?>
</div>

<div class="footer">Comisión Nacional de Energía Atómica · TANDAR</div>
</body>
</html>