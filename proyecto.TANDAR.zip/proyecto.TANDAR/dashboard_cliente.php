<?php
require_once 'includes/config.php';
require_once 'includes/session.php';
session_init();
require_login();

$nombre = $_SESSION['user_nombre'];
$inicial = strtoupper(substr($nombre, 0, 1));
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel Cliente — <?= htmlspecialchars(APP_NAME) ?></title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="/public/css/styles.css">
</head>
<body class="dashboard-page">

    <nav class="navbar-netflix scrolled">
        <a href="#" class="brand-logo"><?= htmlspecialchars(APP_NAME) ?></a>
        <div class="nav-profile-section">
            <span class="d-none d-sm-inline text-muted small">Hola, <strong><?= htmlspecialchars($nombre) ?></strong></span>
            <div class="profile-avatar"><?= $inicial ?></div>
            <a href="/auth/logout.php" class="btn-logout">Cerrar Sesión</a>
        </div>
    </nav>

    <header class="role-hero">
        <div class="hero-content">
            <div class="hero-badge"><i class="fas fa-user"></i> Rol Cliente</div>
            <h1 class="hero-title">Bienvenido, <?= htmlspecialchars($nombre) ?></h1>
            <p class="hero-description">Tu cuenta está activa con permisos de cliente. Desde aquí podés acceder a las opciones básicas del sistema.</p>
            <div class="hero-buttons">
                <a class="btn btn-play" href="/auth/recover.php"><i class="fas fa-key"></i> Cambiar clave</a>
            </div>
        </div>
    </header>

</body>
</html>