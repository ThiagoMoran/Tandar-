<?php
require_once 'includes/config.php';
require_once 'includes/session.php';

session_init();
require_login();

$rol = $_SESSION['user_rol'];

match ($rol) {
    'administrador'           => header('Location: /turnos/panel_admin.php'),
    'responsable_linea' => header('Location: /turnos/panel_responsable.php'),
    default                   => header('Location: /turnos/mis_turnos.php'),
};
exit;
?>


<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Dashboard — <?= htmlspecialchars(APP_NAME) ?></title>
<link rel="stylesheet" href="/public/css/styles.css">
</head>
<body>

<nav class="navbar">
  <a href="/index.php" class="navbar-brand"><?= htmlspecialchars(APP_NAME) ?></a>
  <div class="navbar-user">
    <span><?= htmlspecialchars($nombre) ?></span>
    <span class="badge-rol <?= $rol ?>"><?= ucfirst($rol) ?></span>
    <?php if ($rol === 'administrador'): ?>
      <a href="/admin/users.php">Panel Admin</a>
    <?php endif; ?>
    <a href="/auth/logout.php">Cerrar sesión</a>
  </div>
</nav>

<div class="container">

  <?php if ($rol === 'administrador'): ?>
    <div class="card">
      <h3>Panel de Administrador</h3>
      <p>Bienvenido, <strong><?= htmlspecialchars($nombre) ?></strong>. Tenés acceso total al sistema.</p>
      <br>
      <a href="/admin/users.php" class="btn btn-primary" style="width:auto;display:inline-block;padding:10px 24px">
        Gestionar usuarios
      </a>
    </div>

  <?php elseif ($rol === 'supervisor'): ?>
    <div class="card">
      <h3>Panel de Supervisor</h3>
      <p>Bienvenido, <strong><?= htmlspecialchars($nombre) ?></strong>. Podés ver reportes y moderar contenido.</p>
    </div>

  <?php else: ?>
    <div class="card">
      <h3>Bienvenido</h3>
      <p>Hola, <strong><?= htmlspecialchars($nombre) ?></strong>. Estás logueado como usuario.</p>
    </div>
  <?php endif; ?>

  <div class="card">
    <h3>Tu cuenta</h3>
    <table>
      <tr><th>Nombre</th><td><?= htmlspecialchars($nombre) ?></td></tr>
      <tr><th>Email</th><td><?= htmlspecialchars($email) ?></td></tr>
      <tr><th>Rol</th><td><?= ucfirst($rol) ?></td></tr>
    </table>
  </div>

</div>
</body>
</html>