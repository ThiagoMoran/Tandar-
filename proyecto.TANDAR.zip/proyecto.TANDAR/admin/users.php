<?php
require_once '../includes/config.php';
require_once '../includes/session.php';
require_once '../includes/db.php';

session_init();
require_role('administrador');

$msg = '';
$msgTipo = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cambiar_rol'])) {
    if (!csrf_verify($_POST['_csrf'] ?? '')) { $msg = 'Token inválido.'; $msgTipo = 'error'; }
    else {
        $uid = (int)$_POST['usuario_id']; $rid = (int)$_POST['rol_id'];
        if ($uid === (int)$_SESSION['user_id']) { $msg = 'No podés cambiar tu propio rol.'; $msgTipo = 'error'; }
        else { db()->prepare('UPDATE usuarios SET rol_id=? WHERE id=?')->execute([$rid, $uid]); $msg = 'Rol actualizado.'; $msgTipo = 'ok'; }
    }
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle_activo'])) {
    if (!csrf_verify($_POST['_csrf'] ?? '')) { $msg = 'Token inválido.'; $msgTipo = 'error'; }
    else {
        $uid = (int)$_POST['usuario_id']; $activo = (int)$_POST['activo'];
        if ($uid === (int)$_SESSION['user_id']) { $msg = 'No podés desactivarte a vos mismo.'; $msgTipo = 'error'; }
        else { db()->prepare('UPDATE usuarios SET activo=? WHERE id=?')->execute([$activo, $uid]); $msg = 'Usuario '.($activo?'activado':'desactivado').'.'; $msgTipo = 'ok'; }
    }
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['eliminar'])) {
    if (!csrf_verify($_POST['_csrf'] ?? '')) { $msg = 'Token inválido.'; $msgTipo = 'error'; }
    else {
        $uid = (int)$_POST['usuario_id'];
        if ($uid === (int)$_SESSION['user_id']) { $msg = 'No podés eliminarte a vos mismo.'; $msgTipo = 'error'; }
        else { db()->prepare('DELETE FROM usuarios WHERE id=?')->execute([$uid]); $msg = 'Usuario eliminado.'; $msgTipo = 'ok'; }
    }
}

$usuarios = db()->query('SELECT u.id,u.nombre,u.email,u.activo,u.creado_en,r.id AS rol_id,r.nombre AS rol_nombre FROM usuarios u JOIN roles r ON r.id=u.rol_id ORDER BY u.creado_en DESC')->fetchAll();
$roles = db()->query('SELECT * FROM roles')->fetchAll();

$total = count($usuarios);
$activos = count(array_filter($usuarios, fn($u) => $u['activo']));
$admins = count(array_filter($usuarios, fn($u) => $u['rol_nombre'] === 'administrador'));

if (empty($_SESSION['_csrf'])) $_SESSION['_csrf'] = bin2hex(random_bytes(32));

function iniciales($nombre) {
    $p = explode(' ', trim($nombre));
    return strtoupper(substr($p[0],0,1) . (isset($p[1]) ? substr($p[1],0,1) : ''));
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Administración de Usuarios — TANDAR</title>
<link rel="stylesheet" href="/public/css/tandar.css">
<style>
.tn-rol-badge {
    padding: 3px 10px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 700;
}
.tn-rol-administrador { background: var(--nar-lt); color: #a0400e; }
.tn-rol-responsable    { background: var(--azul-lt); color: #1a3a7a; }
.tn-rol-usuario        { background: var(--verde-lt); color: #1a6b3a; }

.tn-rol-sel {
    background: #f8fafc;
    border: 1px solid var(--gris-bd);
    border-radius: 6px;
    padding: 6px 10px;
    font-size: 12px;
    color: var(--texto);
    cursor: pointer;
}

.tn-act-on  { background: var(--verde-lt); color: #1a6b3a; padding: 3px 10px; border-radius: 20px; font-size: 11px; font-weight: 700; }
.tn-act-off { background: var(--rojo-lt);  color: #8b1a1a; padding: 3px 10px; border-radius: 20px; font-size: 11px; font-weight: 700; }

.tn-btn-action {
    background: transparent;
    border: 1.5px solid var(--gris-bd);
    border-radius: 6px;
    padding: 5px 12px;
    font-size: 12px;
    font-weight: 600;
    cursor: pointer;
    color: var(--azul);
    margin-right: 6px;
    transition: all 0.15s;
}
.tn-btn-action:hover { background: var(--azul); color: #fff; border-color: var(--azul); }

.tn-btn-del {
    background: transparent;
    border: 1.5px solid var(--rojo);
    border-radius: 6px;
    padding: 5px 12px;
    font-size: 12px;
    font-weight: 600;
    cursor: pointer;
    color: var(--rojo);
}
.tn-btn-del:hover { background: var(--rojo); color: #fff; }

.tn-user-cell { display: flex; align-items: center; gap: 10px; }
.tn-user-name { font-weight: 700; font-size: 13px; color: var(--azul); }
.tn-user-email { font-size: 11px; color: var(--muted); }

.tn-tbl-toolbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 14px 20px;
    border-bottom: 2px solid var(--gris-bd);
    background: #f8fafc;
}
.tn-tbl-toolbar-title { font-size: 14px; font-weight: 700; color: var(--azul); }
.tn-count-pill {
    background: var(--nar-lt);
    color: var(--naranja);
    font-size: 12px;
    font-weight: 700;
    padding: 3px 12px;
    border-radius: 20px;
}
</style>
</head>
<body>

<div class="tn-topbar">
    <span>TANDAR Intranet — CNEA · Centro Atómico Constituyentes</span>
    <div>
        <span>👤 <?= htmlspecialchars($_SESSION['user_nombre']) ?></span>
        <a href="/auth/logout.php">Cerrar sesión</a>
    </div>
</div>

<nav class="tn-navbar">
    <a href="/turnos/panel_admin.php" class="tn-brand">
        <div class="tn-logo"><span>TAN</span><small>DAR</small></div>
        <div class="tn-brand-text">
            <strong>TANDAR Intranet</strong>
            <em>Panel de administrador</em>
        </div>
    </a>
    <div class="tn-nav-links">
        <a href="/turnos/panel_admin.php">Solicitudes</a>
        <a href="/admin/users.php" class="active">Usuarios</a>
        <a href="/auth/logout.php" class="tn-btn-logout">Salir</a>
    </div>
</nav>

<div class="tn-page-header">
    <h1>Administración de Usuarios</h1>
    <p>Gestión de roles y accesos al sistema</p>
</div>

<div class="tn-container">

    <?php if ($msg): ?>
        <div class="tn-page-alert <?= $msgTipo === 'ok' ? 'success' : 'error' ?>">
            <?= $msgTipo === 'ok' ? '✔' : '⚠' ?> <?= htmlspecialchars($msg) ?>
        </div>
    <?php endif; ?>

    <div class="tn-stats" style="grid-template-columns: repeat(3,1fr);">
        <div class="tn-stat modif">
            <div class="tn-stat-num"><?= $total ?></div>
            <div class="tn-stat-label">Total usuarios</div>
        </div>
        <div class="tn-stat aprov">
            <div class="tn-stat-num"><?= $activos ?></div>
            <div class="tn-stat-label"><?= $total > 0 ? round($activos/$total*100) : 0 ?>% activos</div>
        </div>
        <div class="tn-stat pend">
            <div class="tn-stat-num"><?= $admins ?></div>
            <div class="tn-stat-label">Administradores</div>
        </div>
    </div>

    <div class="tn-tabla-wrap">
        <div class="tn-tbl-toolbar">
            <span class="tn-tbl-toolbar-title">Usuarios registrados</span>
            <span class="tn-count-pill"><?= $total ?> usuarios</span>
        </div>
        <table class="tn-tabla">
            <thead>
                <tr>
                    <th style="width:32%">Usuario</th>
                    <th style="width:20%">Rol</th>
                    <th style="width:13%">Estado</th>
                    <th style="width:13%">Registro</th>
                    <th style="width:22%">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($usuarios as $u): ?>
                <tr>
                    <td>
                        <div class="tn-user-cell">
                            <div class="tn-avatar"><?= htmlspecialchars(iniciales($u['nombre'])) ?></div>
                            <div>
                                <div class="tn-user-name"><?= htmlspecialchars($u['nombre']) ?></div>
                                <div class="tn-user-email"><?= htmlspecialchars($u['email']) ?></div>
                            </div>
                        </div>
                    </td>
                    <td>
                        <form method="post" style="display:inline">
                            <input type="hidden" name="_csrf" value="<?= htmlspecialchars($_SESSION['_csrf']) ?>">
                            <input type="hidden" name="usuario_id" value="<?= $u['id'] ?>">
                            <input type="hidden" name="cambiar_rol" value="1">
                            <select name="rol_id" class="tn-rol-sel" onchange="this.form.submit()" <?= $u['id']===$_SESSION['user_id']?'disabled':'' ?>>
                                <?php foreach ($roles as $r): ?>
                                    <option value="<?= $r['id'] ?>" <?= $r['id']==$u['rol_id']?'selected':'' ?>><?= ucfirst($r['nombre']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </form>
                    </td>
                    <td>
                        <?= $u['activo'] ? '<span class="tn-act-on">Activo</span>' : '<span class="tn-act-off">Inactivo</span>' ?>
                    </td>
                    <td style="color:var(--muted)"><?= date('d/m/Y', strtotime($u['creado_en'])) ?></td>
                    <td>
                        <?php if ($u['id'] !== (int)$_SESSION['user_id']): ?>
                        <form method="post" style="display:inline">
                            <input type="hidden" name="_csrf" value="<?= htmlspecialchars($_SESSION['_csrf']) ?>">
                            <input type="hidden" name="usuario_id" value="<?= $u['id'] ?>">
                            <input type="hidden" name="toggle_activo" value="1">
                            <input type="hidden" name="activo" value="<?= $u['activo'] ? 0 : 1 ?>">
                            <button type="submit" class="tn-btn-action"><?= $u['activo'] ? 'Desactivar' : 'Activar' ?></button>
                        </form>
                        <form method="post" style="display:inline" onsubmit="return confirm('¿Eliminar a <?= htmlspecialchars(addslashes($u['nombre'])) ?>?')">
                            <input type="hidden" name="_csrf" value="<?= htmlspecialchars($_SESSION['_csrf']) ?>">
                            <input type="hidden" name="usuario_id" value="<?= $u['id'] ?>">
                            <input type="hidden" name="eliminar" value="1">
                            <button type="submit" class="tn-btn-del">Eliminar</button>
                        </form>
                        <?php else: ?>
                            <span style="color:var(--muted); font-size:12px;">— vos mismo</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="tn-footer">TANDAR — CNEA · Centro Atómico Constituyentes</div>
</div>
</body>
</html>