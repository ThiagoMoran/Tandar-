<?php
// auth/reset_password.php — Paso 2: cambiar contraseña con token
require_once '../includes/config.php';
require_once '../includes/session.php';
require_once '../includes/db.php';

session_init();

$token = trim($_GET['token'] ?? '');
$error = ''; $success = '';

// Verificar token
$stmt = db()->prepare(
    'SELECT rt.*, u.nombre FROM reset_tokens rt
     JOIN usuarios u ON u.id = rt.usuario_id
     WHERE rt.token = ? AND rt.usado = 0 AND rt.expira_en > NOW()
     LIMIT 1'
);
$stmt->execute([$token]);
$rec = $stmt->fetch();

if (!$rec) {
    $error = 'El enlace no es válido o ya expiró. <a href="/auth/recover.php">Solicitá uno nuevo</a>.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $rec) {
    if (!csrf_verify($_POST['_csrf'] ?? '')) {
        $error = 'Token inválido.';
    } else {
        $pass    = $_POST['password'] ?? '';
        $confirm = $_POST['confirm']  ?? '';
        if (strlen($pass) < 8) {
            $error = 'La contraseña debe tener al menos 8 caracteres.';
        } elseif ($pass !== $confirm) {
            $error = 'Las contraseñas no coinciden.';
        } else {
            $hash = password_hash($pass, PASSWORD_BCRYPT, ['cost' => HASH_COST]);
            db()->prepare('UPDATE usuarios SET password=? WHERE id=?')
                 ->execute([$hash, $rec['usuario_id']]);
            db()->prepare('UPDATE reset_tokens SET usado=1 WHERE id=?')
                 ->execute([$rec['id']]);
            $success = 'Contraseña actualizada. <a href="/auth/login.php">Iniciá sesión</a>.';
            $rec = null; // no mostrar el form de nuevo
        }
    }
}

if (empty($_SESSION['_csrf'])) $_SESSION['_csrf'] = bin2hex(random_bytes(32));
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Nueva contraseña — <?= htmlspecialchars(APP_NAME) ?></title>
<link rel="stylesheet" href="/public/css/reset_styles.css">
</head>
<body class="auth-page">
<div class="auth-card">
  <h1><?= htmlspecialchars(APP_NAME) ?></h1>
  <h2>Nueva contraseña</h2>

  <?php if ($error):   ?><div class="alert alert-error"><?= $error ?></div><?php endif; ?>
  <?php if ($success): ?><div class="alert alert-ok"><?= $success ?></div><?php endif; ?>

  <?php if ($rec && !$success): ?>
    <p>Hola <strong><?= htmlspecialchars($rec['nombre']) ?></strong>, elegí tu nueva contraseña.</p>
    <form method="post" novalidate>
      <input type="hidden" name="_csrf" value="<?= htmlspecialchars($_SESSION['_csrf']) ?>">
      <input type="hidden" name="token" value="<?= htmlspecialchars($token) ?>">
      <label for="password">Nueva contraseña</label>
      <input type="password" id="password" name="password" required minlength="8">
      <label for="confirm">Repetir contraseña</label>
      <input type="password" id="confirm" name="confirm" required>
      <button type="submit" class="btn btn-primary">Guardar contraseña</button>
    </form>
  <?php endif; ?>
</div>
</body>
</html>