<?php
require_once '../includes/config.php';
require_once '../includes/session.php';

session_init();
logout_user();

header('Location: /auth/login.php');
exit;