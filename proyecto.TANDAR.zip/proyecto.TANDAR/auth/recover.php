<?php
// auth/recover.php — Paso 1: pedir email
require_once '../includes/config.php';
require_once '../includes/session.php';
require_once '../includes/db.php';
require_once '../includes/mailer.php';

session_init();

$msg   = '';
$isErr = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['_csrf'] ?? '')) {
        $msg = 'Token inválido.'; $isErr = true;
    } else {
        $email = trim($_POST['email'] ?? '');
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $msg = 'Ingresá un email válido.'; $isErr = true;
        } else {
            $stmt = db()->prepare('SELECT id, nombre FROM usuarios WHERE email = ? AND activo = 1');
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user) {
                // Invalidar tokens anteriores
                db()->prepare('UPDATE reset_tokens SET usado=1 WHERE usuario_id=?')
                     ->execute([$user['id']]);

                $token = bin2hex(random_bytes(32));
                $expira = date('Y-m-d H:i:s', time() + 1800); // 30 min

                db()->prepare(
                    'INSERT INTO reset_tokens (usuario_id, token, expira_en) VALUES (?,?,?)'
                )->execute([$user['id'], $token, $expira]);

                send_reset_email($email, $user['nombre'], $token);
            }
            // Siempre mostrar el mismo mensaje (no revelar si el email existe)
            $msg = 'Si el email está registrado, recibirás un enlace en los próximos minutos.';
        }
    }
}

if (empty($_SESSION['_csrf'])) $_SESSION['_csrf'] = bin2hex(random_bytes(32));
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Recuperar contraseña — <?= htmlspecialchars(APP_NAME) ?></title>
<link rel="stylesheet" href="/public/css/styles.css">
</head>
<body class="auth-page">
<div class="auth-card">
  <h1><?= htmlspecialchars(APP_NAME) ?></h1>
  <h2>Recuperar contraseña</h2>

  <?php if ($msg): ?>
    <div class="alert <?= $isErr ? 'alert-error' : 'alert-ok' ?>"><?= htmlspecialchars($msg) ?></div>
  <?php endif; ?>

  <form method="post" novalidate>
    <input type="hidden" name="_csrf" value="<?= htmlspecialchars($_SESSION['_csrf']) ?>">
    <label for="email">Email de tu cuenta</label>
    <input type="email" id="email" name="email" required autofocus>
    <button type="submit" class="btn btn-primary">Enviar enlace</button>
  </form>

  <div class="auth-links"><a href="/auth/login.php">Volver al login</a></div>
</div>
</body>
</html>