<?php
// auth/register.php
require_once '../includes/config.php';
require_once '../includes/session.php';
require_once '../includes/db.php';

session_init();
if (is_logged_in()) {
    header('Location: /index.php');
    exit;
}
$error   = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['_csrf'] ?? '')) {
        $error = 'Token inválido. Recargá la página.';
    } else {
        $nombre   = trim($_POST['nombre']   ?? '');
        $email    = trim($_POST['email']    ?? '');
        $password = $_POST['password']      ?? '';
        $confirm  = $_POST['confirm']       ?? '';

        if (!$nombre || !$email || !$password || !$confirm) {
            $error = 'Completá todos los campos.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'El email no es válido.';
        } elseif (strlen($password) < 8) {
            $error = 'La contraseña debe tener al menos 8 caracteres.';
        } elseif ($password !== $confirm) {
            $error = 'Las contraseñas no coinciden.';
        } else {
            $existe = db()->prepare('SELECT id FROM usuarios WHERE email = ?');
            $existe->execute([$email]);
            if ($existe->fetch()) {
                $error = 'Ya existe una cuenta con ese email.';
            } else {
                $hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => HASH_COST]);
                db()->prepare(
                    'INSERT INTO usuarios (nombre, email, password, rol_id) VALUES (?,?,?,3)'
                )->execute([$nombre, $email, $hash]);
                $success = '¡Cuenta creada! Ya podés <a href="/auth/login.php">iniciar sesión</a>.';
            }
        }
    }
}

if (empty($_SESSION['_csrf'])) $_SESSION['_csrf'] = bin2hex(random_bytes(32));
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Registrarse — <?= htmlspecialchars(APP_NAME) ?></title>
<link rel="stylesheet" href="/public/css/styles.css">   
</head>
<body class="auth-page">
<div class="auth-card">
  <h1><?= htmlspecialchars(APP_NAME) ?></h1>
  <h2>Crear cuenta</h2>

  <?php if ($error):   ?><div class="alert alert-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
  <?php if ($success): ?><div class="alert alert-ok"><?= $success ?></div><?php endif; ?>

  <form method="post" novalidate>
    <input type="hidden" name="_csrf" value="<?= htmlspecialchars($_SESSION['_csrf']) ?>">

    <label for="nombre">Nombre completo</label>
    <input type="text" id="nombre" name="nombre" required value="<?= htmlspecialchars($_POST['nombre'] ?? '') ?>">

    <label for="email">Email</label>
    <input type="email" id="email" name="email" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">

    <label for="password">Contraseña <small>(mín. 8 caracteres)</small></label>
    <input type="password" id="password" name="password" required minlength="8">

    <label for="confirm">Repetir contraseña</label>
    <input type="password" id="confirm" name="confirm" required>

    <button type="submit" class="btn btn-primary">Registrarme</button>
  </form>

  <div class="auth-links">
    <a href="/auth/login.php">¿Ya tenés cuenta? Iniciá sesión</a>
  </div>
</div>
</body>
</html>