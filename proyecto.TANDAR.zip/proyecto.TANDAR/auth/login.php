<?php
// auth/login.php
require_once '../includes/config.php';
require_once '../includes/session.php';
require_once '../includes/db.php';

session_init();

if (is_logged_in()) { header('Location: /index.php'); exit; }

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CSRF
    if (!csrf_verify($_POST['_csrf'] ?? '')) {
        $error = 'Token inválido. Recargá la página.';
    } else {
        $email    = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if (!$email || !$password) {
            $error = 'Completá todos los campos.';
        } else {
            $stmt = db()->prepare(
                'SELECT u.*, r.nombre AS rol_nombre
                 FROM usuarios u
                 JOIN roles r ON r.id = u.rol_id
                 WHERE u.email = ? AND u.activo = 1
                 LIMIT 1'
            );
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user && $user['password'] && password_verify($password, $user['password'])) {
                // Actualiza el hash si bcrypt detecta costo desactualizado
                if (password_needs_rehash($user['password'], PASSWORD_BCRYPT, ['cost' => HASH_COST])) {
                    $nuevo = password_hash($password, PASSWORD_BCRYPT, ['cost' => HASH_COST]);
                    db()->prepare('UPDATE usuarios SET password=? WHERE id=?')
                         ->execute([$nuevo, $user['id']]);
                }
                login_user($user);
                header('Location: /index.php');
                exit;
            } else {
                $error = 'Email o contraseña incorrectos.';
            }
        }
    }
}

// Generar token CSRF para el formulario
if (empty($_SESSION['_csrf'])) {
    $_SESSION['_csrf'] = bin2hex(random_bytes(32));
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Iniciar sesión — TANDAR</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');

:root {
    --azul: #1a3a52;
    --naranja: #e8632a;
    --gris-bd: #e8eaed;
    --texto: #1a2733;
    --muted: #8893a1;
    --rojo: #d64545;
    --rojo-lt: #fdeeee;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
body {
    font-family: 'Inter', -apple-system, sans-serif;
    background: linear-gradient(135deg, #14304a 0%, var(--azul) 50%, #1f4a6b 100%);
    min-height: 100vh;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    position: relative;
    overflow: hidden;
}
.bg-dots {
    position: absolute; inset: 0;
    background-image: radial-gradient(circle, rgba(232,99,42,0.18) 1px, transparent 1px);
    background-size: 30px 30px;
}
.login-box {
    position: relative; z-index: 2;
    background: white;
    border-radius: 20px;
    padding: 44px;
    width: 400px;
    box-shadow: 0 25px 70px rgba(0,0,0,0.35);
    border-top: 4px solid var(--naranja);
}
.login-logo { text-align: center; margin-bottom: 30px; }
.logo-box {
    width: 58px; height: 58px;
    background: linear-gradient(135deg, var(--azul), #0d2235);
    border-radius: 16px;
    display: inline-flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    margin-bottom: 14px;
    gap: 1px;
    box-shadow: 0 4px 14px rgba(26,58,82,0.4);
}
.logo-box span  { color: var(--naranja); font-size: 15px; font-weight: 800; letter-spacing: 1px; }
.logo-box small { color: #9bb8d0; font-size: 8px; letter-spacing: 0.6px; }
.login-logo h2  { font-size: 19px; color: var(--azul); font-weight: 800; letter-spacing: -0.02em; }
.login-logo p   { font-size: 12.5px; color: var(--muted); margin-top: 4px; font-weight: 500; }
label {
    display: block;
    font-size: 13px;
    font-weight: 700;
    color: var(--azul);
    margin-bottom: 7px;
}
input {
    width: 100%;
    padding: 12px 14px;
    border: 1px solid var(--gris-bd);
    border-radius: 10px;
    font-size: 14px;
    margin-bottom: 18px;
    color: var(--texto);
    font-family: inherit;
    transition: all 0.15s;
}
input:focus {
    outline: none;
    border-color: #2a5f8f;
    box-shadow: 0 0 0 3px rgba(42,95,143,0.12);
}
.btn-login {
    width: 100%;
    padding: 13px;
    background: var(--naranja);
    color: white;
    border: none;
    border-radius: 10px;
    font-size: 14.5px;
    font-weight: 700;
    cursor: pointer;
    transition: all 0.15s;
    box-shadow: 0 4px 14px rgba(232,99,42,0.3);
}
.btn-login:hover { background: #d4571f; transform: translateY(-1px); box-shadow: 0 6px 18px rgba(232,99,42,0.4); }
.error {
    background: var(--rojo-lt);
    color: #b13030;
    padding: 11px 15px;
    border-radius: 10px;
    margin-bottom: 18px;
    font-size: 13px;
    border-left: 3px solid var(--rojo);
    font-weight: 500;
}
.divider {
    display: flex;
    align-items: center;
    text-align: center;
    margin: 22px 0;
    color: var(--muted);
    font-size: 12px;
    font-weight: 500;
}
.divider::before, .divider::after {
    content: '';
    flex: 1;
    border-bottom: 1px solid var(--gris-bd);
}
.divider span { padding: 0 14px; }

.btn-google {
    width: 100%;
    padding: 12px;
    background: white;
    border: 1.5px solid var(--gris-bd);
    border-radius: 10px;
    font-size: 14px;
    font-weight: 600;
    color: var(--texto);
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    text-decoration: none;
    transition: all 0.15s;
}
.btn-google:hover { background: #f8fafc; border-color: #2a5f8f; }
.btn-google img { width: 18px; height: 18px; }

.auth-links {
    display: flex;
    justify-content: space-between;
    margin-top: 22px;
    font-size: 12.5px;
}
.auth-links a { color: var(--naranja); font-weight: 700; text-decoration: none; }
.auth-links a:hover { text-decoration: underline; }

.back-link { text-align: center; margin-top: 22px; font-size: 12.5px; color: var(--muted); }
.back-link a { color: var(--naranja); font-weight: 700; text-decoration: none; }

.cnea-footer {
    position: relative; z-index: 2;
    margin-top: 22px;
    font-size: 11px;
    color: rgba(255,255,255,0.45);
    text-align: center;
    font-weight: 500;
}
</style>
</head>
<body>
<div class="bg-dots"></div>

<div class="login-box">
    <div class="login-logo">
        <div class="logo-box">
            <span>TAN</span>
            <small>DAR</small>
        </div>
        <h2>Intranet TANDAR</h2>
        <p>CNEA — Centro Atómico Constituyentes</p>
    </div>

    <?php if ($error): ?>
        <div class="error">⚠ <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="post" action="/auth/login.php" novalidate>
        <input type="hidden" name="_csrf" value="<?= htmlspecialchars($_SESSION['_csrf']) ?>">

        <label for="email">Email institucional</label>
        <input type="email" id="email" name="email" required autofocus
               placeholder="usuario@cnea.gob.ar"
               value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">

        <label for="password">Contraseña</label>
        <input type="password" id="password" name="password" required placeholder="••••••••">

        <button type="submit" class="btn-login">Ingresar a la intranet</button>
    </form>

    <div class="divider"><span>o</span></div>

    <a href="/auth/google.php" class="btn-google">
        <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" alt="Google">
        Continuar con Google
    </a>

    <div class="auth-links">
        <a href="/auth/register.php">Crear cuenta</a>
        <a href="/auth/recover.php">¿Olvidaste la contraseña?</a>
    </div>

    <div class="back-link">
        <a href="/index.html">← Volver al portal público</a>
    </div>
</div>

<div class="cnea-footer">
    Comisión Nacional de Energía Atómica · Sistema de gestión de turnos v1.0
</div>
</body>
</html>