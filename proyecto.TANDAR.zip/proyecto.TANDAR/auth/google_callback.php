<?php
// auth/google_callback.php — recibe el código de Google y autentica al usuario
require_once '../includes/config.php';
require_once '../includes/session.php';
require_once '../includes/db.php';

session_init();

// Verificar state CSRF OAuth
if (empty($_GET['state']) || $_GET['state'] !== ($_SESSION['oauth_state'] ?? '')) {
    die('Estado inválido. Intentá de nuevo.');
}
unset($_SESSION['oauth_state']);

$code = $_GET['code'] ?? '';
if (!$code) { header('Location: /auth/login.php?err=google'); exit; }

// 1) Intercambiar code por access_token
$tokenRes = json_decode(file_get_contents('https://oauth2.googleapis.com/token', false,
    stream_context_create(['http' => [
        'method'  => 'POST',
        'header'  => 'Content-Type: application/x-www-form-urlencoded',
        'content' => http_build_query([
            'code'          => $code,
            'client_id'     => GOOGLE_CLIENT_ID,
            'client_secret' => GOOGLE_CLIENT_SECRET,
            'redirect_uri'  => GOOGLE_REDIRECT_URI,
            'grant_type'    => 'authorization_code',
        ]),
    ]])
), true);

if (empty($tokenRes['access_token'])) {
    header('Location: /auth/login.php?err=google'); exit;
}

// 2) Obtener datos del usuario de Google
$profile = json_decode(file_get_contents(
    'https://www.googleapis.com/oauth2/v3/userinfo',
    false,
    stream_context_create(['http' => [
        'header' => 'Authorization: Bearer ' . $tokenRes['access_token'],
    ]])
), true);

if (empty($profile['sub'])) {
    header('Location: /auth/login.php?err=google'); exit;
}

$googleId = $profile['sub'];
$email    = $profile['email'] ?? '';
$nombre   = $profile['name']  ?? $email;
$avatar   = $profile['picture'] ?? '';

// 3) Buscar o crear usuario
$stmt = db()->prepare(
    'SELECT u.*, r.nombre AS rol_nombre FROM usuarios u
     JOIN roles r ON r.id = u.rol_id
     WHERE u.google_id = ? OR (u.email = ? AND u.activo = 1)
     LIMIT 1'
);
$stmt->execute([$googleId, $email]);
$user = $stmt->fetch();

if ($user) {
    // Actualizar google_id y avatar si no los tenía
    if (!$user['google_id']) {
        db()->prepare('UPDATE usuarios SET google_id=?, avatar=? WHERE id=?')
             ->execute([$googleId, $avatar, $user['id']]);
    }
} else {
    // Crear nuevo usuario con rol "usuario" (3)
    db()->prepare(
        'INSERT INTO usuarios (nombre, email, google_id, avatar, rol_id) VALUES (?,?,?,?,3)'
    )->execute([$nombre, $email, $googleId, $avatar]);
    $userId = db()->lastInsertId();

    $stmt2 = db()->prepare(
        'SELECT u.*, r.nombre AS rol_nombre FROM usuarios u
         JOIN roles r ON r.id = u.rol_id WHERE u.id = ?'
    );
    $stmt2->execute([$userId]);
    $user = $stmt2->fetch();
}

login_user($user);

match ($user['rol_nombre']) {
    'administrador'      => header('Location: /turnos/panel_admin.php'),
    'responsable_linea'  => header('Location: /turnos/panel_responsable.php'),
    default              => header('Location: /turnos/mis_turnos.php'),
};
exit;